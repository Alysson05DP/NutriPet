function abrirJanela() {
    // Define as dimensões da janela
    var largura = 520;
    var altura = 600;

    // Calcula a posição central da janela no centro da tela
    var esquerda = (window.innerWidth - largura) / 2;
    var topo = (window.innerHeight - altura) / 2;

    // Abre a nova janela com as dimensões e posição especificadas
    window.open('login.html', '', 'width=' + largura + ',height=' + altura + ',left=' + esquerda + ',top=' + topo);
}